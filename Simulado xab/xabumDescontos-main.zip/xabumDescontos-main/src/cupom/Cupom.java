package cupom;

import xabum.Compra;

public interface Cupom {
    void aplicaDesconto(Compra compra);
}
